#ifndef HACHAGE_H
#define HACHAGE_H
#include "Reseau.h"


typedef struct table {
    int nE;
    int taille; 
    CellNoeud **tab ; // le table hachage
}TableHachage;










#endif